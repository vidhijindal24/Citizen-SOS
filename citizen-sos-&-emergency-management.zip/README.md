# Citizen SOS - Emergency Response Platform

A production-ready full-stack application for emergency alerts with real-time tracking.

## 🚀 Features
- **SOS Trigger**: 3-step immersive emergency reporting.
- **Admin Dashboard**: Live incident feed with interactive map.
- **Real-time**: Socket.io integration for instant status updates.
- **Security**: Helmet, Rate limiting, and Zod validation.
- **Database**: MongoDB Atlas for persistent alert storage.

## 🛠️ Tech Stack
- **Frontend**: React + Vite + Tailwind CSS + Framer Motion.
- **Backend**: Express + Node.js.
- **Real-time**: Socket.io.
- **Database**: MongoDB (Mongoose).
- **Maps**: Leaflet + OpenStreetMap.

## 📦 Deployment Instructions

### Backend (e.g., Render)
1. Create a dynamic web service.
2. Set Environment Variables:
   - `MONGODB_URI`: Your MongoDB Atlas connection string.
   - `PORT`: 3000 (standard).
   - `FRONTEND_URL`: URL of your deployed frontend.
   - `NODE_ENV`: production.

### Frontend (e.g., Vercel)
1. Import the repository.
2. Set Environment Variables:
   - `VITE_API_BASE_URL`: URL of your deployed backend.
3. Build Command: `npm run build`.
4. Output Directory: `dist`.

## ⚙️ Environment Variables (.env)
```env
MONGODB_URI=
PORT=3000
FRONTEND_URL=
VITE_API_BASE_URL=
```

## 📜 API Documentation
- `POST /api/sos/create`: Submit a new alert.
- `GET /api/sos/all`: Fetch all incidents.
- `GET /api/sos/:id`: Fetch specific incident info.
- `PUT /api/sos/update/:id`: Update status (ACTIVE/IN_PROGRESS/RESOLVED).
- `DELETE /api/sos/delete/:id`: Remove (admin only).

// Force empty base URL for unified backend/frontend on same port
const API_BASE_URL = "";

export const api = {
  fetch: async (path: string, options: RequestInit = {}) => {
    let baseUrl = API_BASE_URL;
    if (baseUrl.endsWith("/")) {
      baseUrl = baseUrl.slice(0, -1);
    }
    let cleanPath = path;
    if (!cleanPath.startsWith("/")) {
      cleanPath = `/${cleanPath}`;
    }
    const url = path.startsWith("http") ? path : `${baseUrl}${cleanPath}`;
    return fetch(url, options);
  }
};

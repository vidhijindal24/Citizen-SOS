import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const PRIORITY_COLORS = {
  CRITICAL: 'bg-red-600 text-white shadow-[0_0_15px_-3px_rgba(220,38,38,0.5)]',
  MEDIUM: 'bg-yellow-500 text-black shadow-[0_0_15px_-3px_rgba(245,158,11,0.5)]',
  LOW: 'bg-blue-600 text-white shadow-[0_0_15px_-3px_rgba(37,99,235,0.5)]',
};

export const STATUS_COLORS = {
  ACTIVE: 'text-red-500',
  IN_PROGRESS: 'text-yellow-500',
  RESOLVED: 'text-emerald-500',
};

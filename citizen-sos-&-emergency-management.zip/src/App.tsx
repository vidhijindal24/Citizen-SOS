import { Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import Home from './pages/Home';
import SOSAlert from './pages/SOSAlert';
import Dashboard from './pages/Dashboard';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout><Home /></Layout>} />
      <Route path="/sos" element={<Layout><SOSAlert /></Layout>} />
      <Route path="/dashboard" element={<Dashboard />} />
    </Routes>
  );
}

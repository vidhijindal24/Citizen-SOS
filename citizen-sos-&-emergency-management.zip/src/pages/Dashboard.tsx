import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Activity, Users, AlertCircle, CheckCircle2, MapPin, 
  Phone, Clock, Search, Filter, MoreHorizontal,
  ChevronRight, ArrowRight, ShieldAlert, BadgeInfo,
  X, AlertTriangle, Siren, Radio, Navigation2,
  Lock, Zap, LayoutGrid, ListFilter
} from 'lucide-react';
import Map from '../components/Map';
import { cn, PRIORITY_COLORS, STATUS_COLORS } from '../lib/utils';
import { io } from 'socket.io-client';
import useSound from 'use-sound';

import { api } from '../lib/api';

const socket = io(import.meta.env.VITE_API_BASE_URL || window.location.origin);

// Simulated Responders
const RESPONDERS = [
  { id: 'R1', name: 'Unit Delta-9', type: 'Police', status: 'Available' },
  { id: 'R2', name: 'Medic Echo-4', type: 'Medical', status: 'Available' },
  { id: 'R3', name: 'Fire Squad 12', type: 'Fire', status: 'Available' },
  { id: 'R4', name: 'Rapid Response A', type: 'General', status: 'In Mission' },
];

export default function Dashboard() {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [selectedAlert, setSelectedAlert] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState('All');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const [isDiagnosticOpen, setIsDiagnosticOpen] = useState(false);
  const [diagResult, setDiagResult] = useState<any>(null);
  const [isDiagLoading, setIsDiagLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  const [playSiren] = useSound('https://assets.mixkit.co/active_storage/sfx/950/950-preview.mp3', { volume: 0.5 });

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const runDiagnostic = async (type: 'health' | 'insert' | 'fetch') => {
    setIsDiagLoading(true);
    setDiagResult(null);
    try {
      let endpoint = '';
      if (type === 'health') endpoint = '/api/health';
      if (type === 'insert') endpoint = '/api/sos-test/test-insert';
      if (type === 'fetch') endpoint = '/api/sos/all';

      const res = await api.fetch(endpoint);
      const result = await res.json();
      setDiagResult({ type, status: (res.ok && (result.success !== false)) ? 'success' : 'error', data: result });
    } catch (err: any) {
      setDiagResult({ type, status: 'error', data: { message: err.message } });
    } finally {
      setIsDiagLoading(false);
    }
  };

  const EMERGENCY_TYPES = ['All', 'Medical', 'Fire', 'Crime', 'Women Safety', 'Accident', 'Other'];

  useEffect(() => {
    // Initial Fetch
    const fetchAlerts = async () => {
      try {
        const response = await api.fetch('/api/sos/all');
        const result = await response.json();
        if (response.ok && result.success) {
          setAlerts(result.data);
        }
      } catch (error) {
        console.error("Dashboard list error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchAlerts();

    // Socket listeners for real-time updates
    socket.on('alert-received', (newAlert) => {
      console.log('New alert received via socket:', newAlert);
      setAlerts(prev => [newAlert, ...prev]);
      playSiren();
    });

    socket.on('alert-status-changed', (updatedAlert) => {
      console.log('Alert status changed via socket:', updatedAlert);
      setAlerts(prev => prev.map(a => a._id === updatedAlert._id ? updatedAlert : a));
      if (selectedAlert && (selectedAlert._id === updatedAlert._id || selectedAlert._id === updatedAlert.id)) {
        setSelectedAlert(updatedAlert);
      }
    });

    return () => {
      socket.off('alert-received');
      socket.off('alert-status-changed');
    };
  }, [selectedAlert, playSiren]);

  const handleUpdateStatus = async (alertId: string, status: string) => {
    try {
      const response = await api.fetch(`/api/sos/update/${alertId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      
      if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        throw new Error(result.message || "Failed to update status");
      }
    } catch (error: any) {
      console.error("Error updating status:", error);
    }
  };

  const handleAssignResponder = async (alertId: string, responderName: string) => {
    try {
      const response = await api.fetch(`/api/sos/assign/${alertId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ responderName })
      });
      if (!response.ok) {
        const result = await response.json().catch(() => ({}));
        throw new Error(result.message || "Failed to assign responder");
      }
    } catch (error: any) {
      console.error("Error assigning responder:", error);
    }
  };

  const filteredAlerts = filterType === 'All' 
    ? alerts 
    : alerts.filter(a => a.emergencyType === filterType);

  const stats = {
    total: alerts.length,
    active: alerts.filter(a => a.status === 'ACTIVE').length,
    inProgress: alerts.filter(a => a.status === 'IN_PROGRESS').length,
    resolved: alerts.filter(a => a.status === 'RESOLVED').length,
    critical: alerts.filter(a => a.priorityLevel === 'CRITICAL').length,
  };

  const markers = filteredAlerts.map(a => ({
    id: a._id,
    position: [a.latitude, a.longitude] as [number, number],
    label: a.fullName,
    type: a.emergencyType,
    priority: a.priorityLevel
  }));

  return (
    <div className="flex flex-col flex-1 h-screen bg-[#050505] text-white font-sans overflow-hidden selection:bg-red-500/30 relative">
      <div className="scanline" />
      {/* HUD HEADER */}
      <header className="h-14 border-b border-white/5 flex items-center justify-between px-6 bg-black/40 backdrop-blur-xl z-50 shrink-0">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-red-500 animate-pulse" />
            <h1 className="text-xs font-black uppercase tracking-[0.4em] text-white/90">Command Central <span className="opacity-30">/ Nexus v2.2</span></h1>
          </div>
          <div className="h-4 w-px bg-white/10" />
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded bg-red-500/10 border border-red-500/20">
              <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
              <span className="text-[10px] font-black tracking-[0.2em] text-red-500">{stats.active} ACTIVE EVENTS</span>
            </div>
            <div className="hidden lg:flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded">
              <Clock className="w-3 h-3 text-blue-400" />
              <span className="text-[10px] font-mono font-bold tracking-widest text-blue-400">
                {currentTime.toLocaleTimeString([], { hour12: false })}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-6 text-[10px] uppercase font-black tracking-widest opacity-40">
            <div className="flex items-center gap-2">
              <Navigation2 className="w-3 h-3" />
              <span>SATELLITE_LOCK: OPTIMAL</span>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="w-3 h-3" />
              <span>SECURE_LINK: YES</span>
            </div>
          </div>
          <button 
            onClick={() => setIsDiagnosticOpen(!isDiagnosticOpen)}
            className={cn(
              "p-2 rounded-lg transition-all",
              isDiagnosticOpen ? "bg-blue-500 text-white" : "hover:bg-white/5 opacity-50 hover:opacity-100"
            )}
          >
            <Activity className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex flex-1 min-h-0 relative">
        {/* DIAGNOSTIC PANEL (Floating) */}
        <AnimatePresence>
          {isDiagnosticOpen && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="absolute top-4 right-4 z-[60] w-80 bg-zinc-900/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-3xl overflow-hidden p-4"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-[10px] font-black uppercase tracking-widest text-blue-400 flex items-center gap-2">
                  <LayoutGrid className="w-3 h-3" />
                  Atlas Diagnostic Bridge
                </h3>
                <button onClick={() => setIsDiagnosticOpen(false)}>
                  <X className="w-3 h-3 opacity-20 hover:opacity-100 transition-opacity" />
                </button>
              </div>
              <div className="space-y-1">
                {['health', 'insert', 'fetch'].map((t) => (
                  <button 
                    key={t}
                    onClick={() => runDiagnostic(t as any)}
                    className="w-full text-left p-3 rounded-xl bg-white/5 hover:bg-white/10 text-[9px] font-black uppercase tracking-widest transition-all flex items-center justify-between group"
                  >
                    <span>Run_{t}_Sync</span>
                    <ArrowRight className="w-3 h-3 opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all" />
                  </button>
                ))}
              </div>
              {diagResult && (
                <div className="mt-4 p-3 bg-black/40 border border-white/5 rounded-xl font-mono text-[9px] max-h-40 overflow-y-auto no-scrollbar">
                  <p className={cn("mb-2 uppercase font-black flex items-center gap-2", diagResult.status === 'success' ? 'text-emerald-500' : 'text-red-500')}>
                    <BadgeInfo className="w-3 h-3" />
                    [{diagResult.status.toUpperCase()}] :: RESPONSE_BLOCK
                  </p>
                  <pre className="opacity-50 whitespace-pre-wrap leading-tight text-[8px] font-mono">{JSON.stringify(diagResult.data, null, 2)}</pre>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
 
        {/* SIDEBAR: LIST & STATS */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.aside 
              initial={{ x: -340 }}
              animate={{ x: 0 }}
              exit={{ x: -340 }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute md:relative inset-y-0 left-0 w-full md:w-[340px] bg-black border-r border-white/5 flex flex-col shrink-0 z-40 h-full"
            >
              {/* MOBILE CLOSE */}
              <div className="md:hidden flex p-4 border-b border-white/5 justify-between items-center">
                <span className="text-[10px] font-black uppercase tracking-widest opacity-40">Navigator_Active</span>
                <button onClick={() => setIsSidebarOpen(false)} className="p-2 border border-white/10 rounded-lg">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* STATS STRIP */}
              <div className="grid grid-cols-2 border-b border-white/5">
                {[
                  { label: 'Signal_Total', val: stats.total, color: 'text-white/40', icon: Radio },
                  { label: 'Critical_Active', val: stats.critical, color: 'text-red-500', icon: AlertTriangle },
                  { label: 'Protocol_Clear', val: stats.resolved, color: 'text-emerald-500', icon: CheckCircle2 },
                  { label: 'Unit_Linked', val: stats.inProgress, color: 'text-yellow-500', icon: Activity },
                ].map((s) => (
                  <div key={s.label} className="p-6 border-r border-b border-white/5 last:border-r-0 flex flex-col items-center justify-center relative overflow-hidden group">
                    <div className="absolute inset-0 bg-white/[0.01] group-hover:bg-white/[0.03] transition-colors" />
                    <s.icon className={cn("w-3 h-3 mb-2 opacity-20 group-hover:opacity-100 transition-opacity", s.color)} />
                    <span className="text-[7px] font-black uppercase tracking-widest opacity-20 mb-1">{s.label}</span>
                    <span className={cn("text-3xl font-black font-mono italic tracking-tighter leading-none transition-all group-hover:scale-110", s.color)}>{s.val}</span>
                  </div>
                ))}
              </div>

              {/* LIST CONTROLS */}
              <div className="p-4 space-y-4">
                <div className="flex items-center gap-2 px-3 py-2 bg-white/5 border border-white/5 rounded-xl">
                  <Search className="w-3 h-3 opacity-20" />
                  <input 
                    type="text" 
                    placeholder="SCAN_IDENTITIES..." 
                    className="bg-transparent border-0 outline-none text-[10px] font-bold uppercase tracking-widest placeholder:opacity-20 flex-1"
                  />
                </div>
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                  {EMERGENCY_TYPES.map(type => (
                    <button
                      key={type}
                      onClick={() => setFilterType(type)}
                      className={cn(
                        "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest whitespace-nowrap transition-all border",
                        filterType === type 
                          ? "bg-white text-black border-white" 
                          : "bg-white/5 border-white/10 text-white/30 hover:text-white"
                      )}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* LIVE FEED */}
              <div className="flex-1 overflow-y-auto px-4 space-y-2 no-scrollbar pb-8">
                {loading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <div key={i} className="h-20 bg-white/5 rounded-xl animate-pulse" />
                  ))
                ) : filteredAlerts.length === 0 ? (
                  <div className="py-20 text-center opacity-10">
                    <Radio className="w-12 h-12 mx-auto mb-4" />
                    <p className="text-[10px] uppercase font-black tracking-widest">No Signals Detected</p>
                  </div>
                ) : (
                  filteredAlerts.map((alert) => (
                    <motion.div
                      layout
                      key={alert._id}
                      onClick={() => {
                        setSelectedAlert(alert);
                        if (window.innerWidth < 768) setIsSidebarOpen(false);
                      }}
                      className={cn(
                        "p-4 rounded-xl border transition-all cursor-pointer relative group overflow-hidden",
                        selectedAlert?._id === alert._id 
                          ? "bg-white/10 border-white/20 shadow-[0_0_20px_-5px_rgba(255,255,255,0.1)]" 
                          : "bg-white/[0.02] border-white/5 hover:bg-white/[0.05] hover:border-white/10"
                      )}
                    >
                      {alert.status === 'ACTIVE' && (
                        <div className={cn(
                          "absolute top-0 right-0 w-24 h-24 blur-[40px] opacity-10 pointer-events-none",
                          alert.priorityLevel === 'CRITICAL' ? "bg-red-500" : 
                          alert.priorityLevel === 'MEDIUM' ? "bg-yellow-500" : "bg-blue-500"
                        )} />
                      )}

                      <div className="flex justify-between items-start mb-2 relative z-10">
                        <div className="flex items-center gap-2">
                          <span className={cn(
                            "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter",
                            alert.priorityLevel === 'CRITICAL' ? "bg-red-500/20 text-red-500" : 
                            alert.priorityLevel === 'MEDIUM' ? "bg-yellow-500/20 text-yellow-500" :
                            "bg-blue-500/20 text-blue-500"
                          )}>
                            {alert.priorityLevel}
                          </span>
                        </div>
                        <span className="text-[10px] font-mono opacity-20 group-hover:opacity-100 transition-opacity">
                          {new Date(alert.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      <h4 className="text-sm font-black uppercase italic tracking-tighter mb-1 relative z-10">{alert.fullName}</h4>
                      <div className="flex items-center justify-between relative z-10">
                        <p className="text-[9px] opacity-30 uppercase font-bold tracking-widest truncate max-w-[150px]">{alert.emergencyType}</p>
                        <div className="flex items-center gap-1">
                          <div className={cn("w-1 h-1 rounded-full", STATUS_COLORS[alert.status as keyof typeof STATUS_COLORS])} />
                          <span className={cn("text-[8px] font-black uppercase tracking-widest", STATUS_COLORS[alert.status as keyof typeof STATUS_COLORS])}>
                            {alert.status}
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* MAP & DETAIL AREA */}
        <main className="flex-1 relative bg-zinc-950 flex flex-col min-w-0">
          {/* Map Layer */}
          <div className="flex-1 relative z-0">
            <div className="radar-sweep absolute inset-0 opacity-20 pointer-events-none" />
            <Map 
              markers={markers} 
              center={selectedAlert ? [selectedAlert.latitude, selectedAlert.longitude] : [20.5937, 78.9629]}
              zoom={selectedAlert ? 15 : 5}
              onMarkerClick={(id) => {
                const alert = alerts.find(a => a._id === id);
                if (alert) setSelectedAlert(alert);
              }}
            />
            
            {/* UI Overlays */}
            <div className="absolute top-6 left-6 z-10 space-y-4">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                  className="w-10 h-10 bg-black/60 backdrop-blur-md rounded-xl border border-white/10 flex items-center justify-center hover:bg-black transition-all"
                >
                  <ListFilter className="w-4 h-4" />
                </button>
                <div className="bg-black/60 backdrop-blur-md px-4 py-2 rounded-xl border border-white/10 flex items-center gap-4">
                  <div className="text-center">
                    <p className="text-[7px] font-black uppercase opacity-20 tracking-tighter">LAT</p>
                    <p className="text-[11px] font-mono font-bold tracking-tighter text-blue-400">{selectedAlert ? selectedAlert.latitude.toFixed(6) : "00.000000"}</p>
                  </div>
                  <div className="w-px h-6 bg-white/5" />
                  <div className="text-center">
                    <p className="text-[7px] font-black uppercase opacity-20 tracking-tighter">LNG</p>
                    <p className="text-[11px] font-mono font-bold tracking-tighter text-blue-400">{selectedAlert ? selectedAlert.longitude.toFixed(6) : "00.000000"}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Scale/Compass Mockup */}
            <div className="absolute bottom-6 left-6 z-10 pointer-events-none opacity-20">
              <div className="w-32 h-32 border border-white/20 rounded-full flex items-center justify-center relative">
                <div className="absolute inset-0 border border-white/5 rounded-full scale-75" />
                <div className="w-px h-4 bg-white absolute top-0" />
                <div className="w-px h-2 bg-white absolute bottom-0" />
                <div className="w-4 h-px bg-white absolute left-0" />
                <div className="w-4 h-px bg-white absolute right-0" />
                <span className="text-[8px] font-black">SCANNING...</span>
              </div>
            </div>
          </div>

          {/* DETAIL DRAWER */}
          <AnimatePresence>
            {selectedAlert && (
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="h-[70vh] md:h-[340px] bg-black border-t border-white/10 z-40 relative shadow-3xl overflow-y-auto md:overflow-hidden"
              >
                <button 
                  onClick={() => setSelectedAlert(null)}
                  className="absolute -top-12 right-6 w-10 h-10 bg-black border border-white/10 rounded-xl flex items-center justify-center hover:bg-white hover:text-black transition-all"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className="h-full flex flex-col md:flex-row">
                  {/* Left: Summary & Identity */}
                  <div className="w-full md:w-[340px] border-r border-white/5 p-6 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <div className={cn(
                          "w-12 h-12 rounded-2xl border flex items-center justify-center",
                          selectedAlert.priorityLevel === 'CRITICAL' ? 'bg-red-500/10 border-red-500/20' : 
                          selectedAlert.priorityLevel === 'MEDIUM' ? 'bg-yellow-500/10 border-yellow-500/20' : 
                          'bg-blue-500/10 border-blue-500/20'
                        )}>
                          <Activity className={cn(
                            "w-6 h-6", 
                            selectedAlert.priorityLevel === 'CRITICAL' ? 'text-red-500' : 
                            selectedAlert.priorityLevel === 'MEDIUM' ? 'text-yellow-500' : 
                            'text-blue-500'
                          )} />
                        </div>
                        <div>
                          <h2 className="text-xl font-black uppercase tracking-tight leading-none mb-1">{selectedAlert.fullName}</h2>
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-[8px] font-black tracking-widest opacity-60 italic">{selectedAlert.phoneNumber}</span>
                            <span className={cn("text-[8px] font-black uppercase tracking-widest", STATUS_COLORS[selectedAlert.status as keyof typeof STATUS_COLORS])}>
                              • {selectedAlert.status}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="bg-white/[0.02] border border-white/5 p-4 rounded-2xl">
                          <div className="flex items-center gap-2 mb-2">
                            <Clock className="w-3 h-3 opacity-20" />
                            <span className="text-[10px] font-black uppercase tracking-widest opacity-20">Transmission Log</span>
                          </div>
                          <p className="text-[11px] leading-relaxed italic opacity-70">&quot;{selectedAlert.emergencyDescription}&quot;</p>
                          <div className="mt-3 flex items-center justify-between text-[9px] font-black opacity-20 uppercase tracking-[0.2em]">
                            <span>TYPE: {selectedAlert.emergencyType}</span>
                            <span>TS: {new Date(selectedAlert.createdAt).toLocaleTimeString()}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleUpdateStatus(selectedAlert._id, 'RESOLVED')}
                        className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-black font-black text-[10px] uppercase tracking-[0.2em] rounded-xl transition-all"
                      >
                        Terminal_Clear
                      </button>
                      <button className="p-3 bg-white/5 border border-white/5 rounded-xl hover:bg-white/10 transition-colors">
                        <Phone className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Middle: Actions & Dispatch */}
                  <div className="flex-1 p-6 flex flex-col gap-6 overflow-y-auto no-scrollbar">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Dispatch Controls */}
                      <div className="space-y-4">
                        <h3 className="text-[10px] font-black uppercase tracking-widest text-white/40 flex items-center gap-2">
                          <ShieldAlert className="w-3 h-3" />
                          Responder Dispatch Pipeline
                        </h3>
                        
                        <div className="space-y-1">
                          {RESPONDERS.map(res => (
                            <button
                              key={res.id}
                              onClick={() => handleAssignResponder(selectedAlert._id, res.name)}
                              className={cn(
                                "w-full flex items-center justify-between p-3 rounded-xl border transition-all text-left group",
                                selectedAlert.assignedResponder === res.name 
                                  ? "bg-amber-500/10 border-amber-500/40 text-amber-500" 
                                  : "bg-white/5 border-white/5 hover:bg-white/10"
                              )}
                            >
                              <div className="flex items-center gap-3">
                                <div className={cn(
                                  "w-2 h-2 rounded-full",
                                  res.status === 'Available' ? 'bg-emerald-500' : 'bg-white/10'
                                )} />
                                <div>
                                  <p className="text-[10px] font-black uppercase">{res.name}</p>
                                  <p className="text-[8px] opacity-40 uppercase tracking-widest">{res.type} • {res.status}</p>
                                </div>
                              </div>
                              <div className={cn(
                                "px-2 py-1 rounded-lg text-[8px] font-black uppercase border transition-all",
                                selectedAlert.assignedResponder === res.name 
                                  ? "bg-amber-500 text-black border-amber-500" 
                                  : "border-white/10 opacity-0 group-hover:opacity-100"
                              )}>
                                {selectedAlert.assignedResponder === res.name ? 'DEPLOYED' : 'ASSIGN'}
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Map/Env Context */}
                      <div className="space-y-4">
                        <h3 className="text-[10px] font-black uppercase tracking-widest text-white/40 flex items-center gap-2">
                          <Zap className="w-3 h-3" />
                          Environment Diagnostics
                        </h3>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { l: 'Network', v: 'HIGH_LATENCY_G5', s: 'text-emerald-500' },
                            { l: 'Encryption', v: 'AES_256_ACTIVE', s: 'text-emerald-500' },
                            { l: 'Air_Quality', v: 'PM2.5_NOMINAL', s: 'text-amber-500' },
                            { l: 'Device_Temp', v: '32.4_CELSIUS', s: 'text-white/40' },
                          ].map(d => (
                            <div key={d.l} className="bg-white/5 border border-white/5 p-3 rounded-xl">
                              <p className="text-[7px] font-black uppercase opacity-20 tracking-tighter mb-1">{d.l}</p>
                              <p className={cn("text-[9px] font-mono font-bold tracking-tighter", d.s)}>{d.v}</p>
                            </div>
                          ))}
                        </div>
                        <div className="bg-red-500/5 border border-red-500/10 p-3 rounded-xl flex items-center gap-3">
                          <AlertTriangle className="w-4 h-4 text-red-500" />
                          <p className="text-[9px] font-bold leading-tight italic opacity-60">
                            Remote signal strength fluctuating. Protocol SIG-9 manually initiated for this zone.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

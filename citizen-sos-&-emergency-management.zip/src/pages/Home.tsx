import { motion } from 'framer-motion';
import { PhoneCall, Shield, Zap, MapPin, Activity, Users, Clock, Flame, Siren, UserX, Car, CloudLightning } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { FeatureCard, EmergencyCategoryCard } from '../components/Cards';

export default function Home() {
  return (
    <div className="">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-24 pb-12">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(204,0,0,0.15),transparent_70%)]" />
        
        <div className="max-w-7xl mx-auto px-6 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="mb-12"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 text-xs font-bold tracking-widest uppercase mb-6">
              <Zap className="w-4 h-4 text-emergency-red" />
              <span>Real-Time Emergency Response</span>
            </div>
            
            <h1 className="text-5xl md:text-8xl font-black mb-8 leading-[0.9] italic tracking-tighter uppercase">
              Emergency <br />
              <span className="text-emergency-red">Command_System</span>
            </h1>
            
            <p className="text-white/60 text-lg md:text-xl max-w-2xl mx-auto mb-12 leading-relaxed font-medium">
              High-frequency SOS distribution protocol with multi-nodal tracking. Secure, rapid, and mission-critical emergency dispatch.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <NavLink to="/sos" className="group relative">
                <div className="absolute -inset-1 bg-emergency-red rounded-full blur opacity-40 group-hover:opacity-75 transition duration-200 sos-pulse" />
                <button className="relative px-8 py-4 bg-emergency-red rounded-full font-bold text-lg flex items-center gap-3 transition-transform hover:scale-105 active:scale-95">
                  <PhoneCall className="w-6 h-6" />
                  Send Emergency SOS
                </button>
              </NavLink>
              
              <button className="px-8 py-4 bg-white/5 border border-white/10 rounded-full font-bold text-lg hover:bg-white/10 transition-colors">
                Learn More
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="mt-20 relative px-4"
          >
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-emergency-red/5 rounded-full blur-[120px]" />
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[
                { icon: Activity, label: "Medical" },
                { icon: Flame, label: "Fire" },
                { icon: UserX, label: "Crime" },
                { icon: Siren, label: "Women Safety" },
                { icon: Car, label: "Accident" },
                { icon: CloudLightning, label: "Disaster" },
              ].map((item, idx) => (
                <EmergencyCategoryCard key={idx} icon={item.icon} label={item.label} />
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-navy-light/50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white">System Features</h2>
            <p className="text-white/50 max-w-2xl mx-auto">
              Our advanced technology ensures that help arrives as quickly as possible with precision tracking and instant coordination.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={Zap} 
              title="One-Tap Ignition" 
              description="Deploy a high-priority distress signal in under 200ms. Optimized for high-stress environments." 
              delay={0.1}
            />
            <FeatureCard 
              icon={MapPin} 
              title="Real-Time Telemetry" 
              description="Continuous GPS polling ensures your exact position is tracked even while in transit." 
              delay={0.2}
            />
            <FeatureCard 
              icon={Activity} 
              title="Nexus Command" 
              description="Full-spectrum oversight for dispatchers through our centralized tactical operations dashboard." 
              delay={0.3}
            />
            <FeatureCard 
              icon={Users} 
              title="Unit Allocation" 
              description="Automated assignment of the nearest specialized responder unit based on incident classification." 
              delay={0.4}
            />
            <FeatureCard 
              icon={Shield} 
              title="Encrypted Channels" 
              description="Military-grade encryption for all voice and data transmissions within the SOS network." 
              delay={0.5}
            />
            <FeatureCard 
              icon={Clock} 
              title="Zero-Latency Sync" 
              description="Real-time status updates and arrival estimations shared instantly with the sender." 
              delay={0.6}
            />
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">How It Works</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
            <div className="hidden md:block absolute top-[60px] left-[15%] right-[15%] h-[2px] bg-white/5 z-0" />
            
            {[
              { step: "01", title: "Signal Ignition", desc: "Initialize high-priority SOS via the Citizen Portal or dedicated signal channels." },
              { step: "02", title: "Nodal Sync", desc: "Live GPS telemetry is synchronized across the global responder network in <50ms." },
              { step: "03", title: "Tactical Response", desc: "The optimal responder unit is dispatched via the Nexus routing engine." }
            ].map((step, idx) => (
              <div key={idx} className="relative z-10 text-center group">
                <div className="w-20 h-20 bg-navy-dark border border-white/10 rounded-[2rem] flex items-center justify-center mx-auto mb-10 text-emergency-red font-black text-2xl shadow-2xl group-hover:bg-emergency-red/10 transition-all">
                  {step.step}
                </div>
                <h4 className="text-xl font-black uppercase italic tracking-tighter mb-4">{step.title}</h4>
                <p className="text-white/40 text-xs font-bold leading-relaxed uppercase tracking-widest">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

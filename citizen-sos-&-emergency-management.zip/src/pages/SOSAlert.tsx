import { useState, useEffect, type FormEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  PhoneCall, MapPin, Activity, Flame, Siren, UserX, Car, CloudLightning, 
  Send, CheckCircle2, Loader2, AlertCircle, Phone, Fingerprint
} from 'lucide-react';
import { EmergencyCategoryCard } from '../components/Cards';
import Map from '../components/Map';
import { io } from 'socket.io-client';
import { toast, Toaster } from 'sonner';

import { api } from '../lib/api';

const socket = io(import.meta.env.VITE_API_BASE_URL || window.location.origin);

const EMERGENCY_TYPES = [
  { id: 'Medical', icon: Activity, label: 'Medical' },
  { id: 'Fire', icon: Flame, label: 'Fire' },
  { id: 'Crime', icon: UserX, label: 'Crime' },
  { id: 'Women Safety', icon: Siren, label: 'Women Safety' },
  { id: 'Accident', icon: Car, label: 'Accident' },
  { id: 'Other', icon: CloudLightning, label: 'Other' },
];

export default function SOSAlert() {
  const [step, setStep] = useState(1);
  const [showConfirm, setShowConfirm] = useState(false);
  const [formData, setFormData] = useState({
    fullName: '',
    phoneNumber: '',
    emergencyType: '',
    emergencyDescription: '',
    additionalNotes: ''
  });
  const [location, setLocation] = useState<{ lat: number, lng: number } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [alertId, setAlertId] = useState<string | null>(null);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Success sound effect
  const playSuccessSound = () => {
    if (!soundEnabled) return;
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3');
    audio.volume = 0.5;
    audio.play().catch(err => console.warn("Audio playback blocked by browser/permission:", err));
  };

  useEffect(() => {
    // Check if user info is in localStorage to speed up repeat usage
    const saved = localStorage.getItem('citizen_sos_user');
    if (saved) {
      setFormData(prev => ({ ...prev, ...JSON.parse(saved) }));
    }
  }, []);

  const handleLocationSelect = (lat: number, lng: number) => {
    setLocation({ lat, lng });
  };

  const handleSOSSubmit = async () => {
    if (!formData.emergencyType || !location) return;

    setIsSubmitting(true);
    const loadingToast = toast.loading('Initializing Emergency Protocol...', {
      description: 'Acquiring secure connection to Atlas Backend...',
    });

    try {
      console.log("🚀 Initiating SOS Submission...");
      console.log("📍 Location:", location);
      console.log("📝 Form Data:", formData);

      // Save user info for next time
      localStorage.setItem('citizen_sos_user', JSON.stringify({
        fullName: formData.fullName,
        phoneNumber: formData.phoneNumber
      }));

      const payload = {
        ...formData,
        latitude: location.lat,
        longitude: location.lng
      };
      
      console.log("📡 Sending POST request to /api/sos/create with payload:", payload);

      const response = await api.fetch('/api/sos/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      console.log("📥 Server Response Status:", response.status);
      console.log("📥 Server Response Headers:", Object.fromEntries(response.headers.entries()));

      let result;
      const contentType = response.headers.get("content-type");
      console.log("📥 Server Response Content-Type:", contentType);

      if (contentType && contentType.includes("application/json")) {
        result = await response.json();
        console.log("📥 Server Response JSON:", result);
      } else {
        const text = await response.text();
        console.error("❌ Non-JSON error response from server. Status:", response.status, "Body preview:", text.slice(0, 500));
        try {
          // One more try to parse as JSON in case content-type was wrong
          const fallbackJson = JSON.parse(text);
          result = fallbackJson;
          console.log("📥 Server Response (Fallback JSON):", result);
        } catch {
          console.error("❌ Failed to parse response as JSON. Status:", response.status);
          if (text.includes("<!DOCTYPE html>") || text.includes("<html")) {
            throw new Error(`The Emergency API is currently unavailable (Status 404 - HTML Fallback). Please check if the backend routes are active.`);
          }
          throw new Error(`Server returned status ${response.status} (Non-JSON). The transmission was interrupted.`);
        }
      }

      if (!response.ok) throw new Error(result.message || result.error || "Failed to submit alert");

      toast.success('Emergency Signal Synchronized', {
        id: loadingToast,
        description: result.message || 'Responders have been notified of your location.',
        duration: 5000,
      });

      playSuccessSound();
      setAlertId(result.data?._id || null);
      setIsSubmitting(false);
      setShowConfirm(false);
      setStep(3);
    } catch (error: any) {
      console.error("SOS Submit Error:", error);
      toast.error('Signal Transmission Failed', {
        id: loadingToast,
        description: error.message || 'Please try calling emergency services directly.',
      });
    } finally {
      setIsSubmitting(false);
      setShowConfirm(false);
    }
  };

  return (
    <div className="w-full min-h-screen bg-navy relative overflow-y-auto">
      <Toaster position="top-center" expand={true} richColors closeButton />
      {/* Background Decorative Elements */}
      <div className="fixed inset-0 opacity-10 pointer-events-none z-0">
        <div className="absolute top-1/4 -left-20 w-80 h-80 bg-emergency-red rounded-full blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-blue-600 rounded-full blur-[100px] animate-pulse delay-700"></div>
      </div>
 
      <div className="relative z-10 max-w-lg mx-auto px-6 py-12 sm:py-20 flex flex-col justify-start min-h-screen">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-10"
            >
              <div className="text-center space-y-4">
                <div className="inline-block px-4 py-1.5 rounded-full bg-emergency-red/10 border border-emergency-red/30 text-emergency-red font-black text-[10px] uppercase tracking-[0.3em]">
                  Emergency Portal Active
                </div>
                <h1 className="text-5xl font-black italic tracking-tighter leading-tight uppercase">
                  What&apos;s Your <span className="text-emergency-red">Emergency?</span>
                </h1>
                <p className="text-slate-400 font-medium max-w-xs mx-auto text-sm">
                  Select a category for immediate assistance dispatch.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {EMERGENCY_TYPES.map((type) => (
                  <motion.button
                    key={type.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setFormData(prev => ({ ...prev, emergencyType: type.id }));
                      setStep(2);
                    }}
                    className="aspect-square glass rounded-3xl p-6 flex flex-col items-center justify-center gap-4 group transition-all hover:bg-emergency-red/10 hover:border-emergency-red/50 shadow-2xl"
                  >
                    <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center group-hover:scale-110 group-hover:bg-emergency-red/20 transition-all">
                      <type.icon className="w-8 h-8 text-white group-hover:text-emergency-red" />
                    </div>
                    <span className="font-black text-xs uppercase tracking-widest text-white/70 group-hover:text-white">
                      {type.label}
                    </span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setStep(1)}
                  className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-white/10"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div className="flex-1">
                  <h2 className="text-2xl font-black uppercase tracking-tight">Incident Details</h2>
                </div>
                <button 
                  onClick={() => setSoundEnabled(!soundEnabled)}
                  className="w-10 h-10 glass rounded-full flex items-center justify-center hover:bg-white/10 text-white/50"
                  title={soundEnabled ? "Mute sound" : "Unmute sound"}
                >
                  {soundEnabled ? (
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"></path><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path><path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path></svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"></path><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
                  )}
                </button>
              </div>

              <div className="space-y-6">
                {/* Visual Type Indicator */}
                <div className="glass p-4 rounded-3xl flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emergency-red/20 flex items-center justify-center">
                    {(() => {
                      const Icon = EMERGENCY_TYPES.find(t => t.id === formData.emergencyType)?.icon;
                      return Icon ? <Icon className="w-6 h-6 text-emergency-red" /> : null;
                    })()}
                  </div>
                  <div>
                    <p className="text-[10px] uppercase font-black tracking-widest opacity-40">Priority Category</p>
                    <p className="text-lg font-bold">{formData.emergencyType}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase tracking-widest ml-1 opacity-60">Full Identity</label>
                    <input 
                      type="text"
                      placeholder="Your Full Name"
                      className="w-full glass rounded-2xl px-6 py-4 outline-none focus:border-emergency-red transition-all font-bold"
                      value={formData.fullName}
                      onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase tracking-widest ml-1 opacity-60">Contact Comms</label>
                    <input 
                      type="tel"
                      placeholder="Phone Number"
                      className="w-full glass rounded-2xl px-6 py-4 outline-none focus:border-emergency-red transition-all font-bold"
                      value={formData.phoneNumber}
                      onChange={(e) => setFormData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase tracking-widest ml-1 opacity-60">Situation Context</label>
                    <textarea 
                      placeholder="Brief description (e.g. Someone is hurt, I see smoke)"
                      className="w-full glass rounded-2xl px-6 py-4 outline-none focus:border-emergency-red transition-all font-medium h-32 resize-none"
                      value={formData.emergencyDescription}
                      onChange={(e) => setFormData(prev => ({ ...prev, emergencyDescription: e.target.value }))}
                    ></textarea>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between ml-1">
                    <label className="text-[10px] font-black uppercase tracking-widest opacity-60">Live Location Feed</label>
                    <div className="flex items-center gap-1.5 text-xs text-success font-black uppercase tracking-tighter">
                      <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse"></div>
                      GPS Synchronized
                    </div>
                  </div>
                  <div className="h-48 glass rounded-3xl overflow-hidden relative shadow-inner">
                    {!location && (
                      <div className="absolute inset-0 bg-navy/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center gap-3">
                        <MapPin className="w-6 h-6 text-emergency-red animate-bounce" />
                        <span className="text-[10px] font-black tracking-widest uppercase opacity-60">Acquiring Satellites...</span>
                      </div>
                    )}
                    <Map showUserLocation onLocationSelect={handleLocationSelect} zoom={16} />
                  </div>
                </div>

                <button 
                  onClick={() => setShowConfirm(true)}
                  disabled={!formData.fullName || !formData.phoneNumber || !formData.emergencyDescription || !location}
                  className="w-full py-5 bg-emergency-red hover:bg-emergency-red/90 disabled:bg-white/5 disabled:opacity-50 disabled:cursor-not-allowed rounded-3xl font-black text-lg uppercase tracking-widest shadow-2xl shadow-emergency-red/20 transition-all flex items-center justify-center gap-3 relative overflow-hidden group"
                >
                  <div className="absolute inset-0 bg-white/20 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700"></div>
                  <Siren className="w-6 h-6" />
                  Trigger SOS
                </button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: "spring", duration: 0.8 }}
              className="text-center space-y-10"
            >
              <div className="relative inline-block">
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: [0, 1.2, 1] }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="w-32 h-32 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto border-4 border-emerald-500/40 relative z-10"
                >
                  <CheckCircle2 className="w-16 h-16 text-emerald-500" />
                </motion.div>
                <motion.div 
                  animate={{ scale: [1, 2], opacity: [0.5, 0] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="absolute inset-0 bg-emerald-500/20 rounded-full blur-2xl"
                ></motion.div>
              </div>

              <div className="space-y-4">
                <motion.h1 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  className="text-5xl font-black italic tracking-tighter leading-tight uppercase"
                >
                  Alert <span className="text-emerald-500">Sent!</span>
                </motion.h1>
                <p className="text-slate-400 font-medium max-w-xs mx-auto text-sm leading-relaxed">
                  Incident reported. Our responders are tracking your location.
                </p>
              </div>

              <div className="glass p-8 rounded-[40px] space-y-6 shadow-2xl">
                <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest border-b border-white/5 pb-4">
                  <span className="opacity-40">Ticket ID</span>
                  <span className="font-mono text-xs">{alertId?.slice(-8).toUpperCase()}</span>
                </div>
                <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest border-b border-white/5 pb-4">
                  <span className="opacity-40">Dispatch ETA</span>
                  <span className="text-warning text-sm">~ 4-6 Mins</span>
                </div>
                <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
                  <span className="opacity-40">Status</span>
                  <span className="px-3 py-1 bg-emergency-red/20 text-emergency-red rounded-full">ACTIVE</span>
                </div>

                <div className="pt-4 space-y-3">
                  <button className="w-full py-4 glass border-white/20 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2">
                    <Phone className="w-4 h-4 text-blue-500" />
                    Audio-link Dispatch
                  </button>
                  <p className="text-[10px] italic opacity-30 text-center">
                    Keep your phone screen on for live tracking updates.
                  </p>
                </div>
              </div>

              <Link to="/" className="inline-block text-[10px] font-black uppercase tracking-widest opacity-60 hover:opacity-100 transition-opacity">
                Return to Command Central
              </Link>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Confirmation Modal Overlay */}
        <AnimatePresence>
          {showConfirm && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-navy/90 backdrop-blur-xl flex items-center justify-center p-6"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                className="glass p-10 rounded-[50px] max-w-sm w-full text-center space-y-8 shadow-[0_50px_100px_rgba(239,68,68,0.2)] border-emergency-red/30"
              >
                <div className="w-20 h-20 bg-emergency-red/20 rounded-full flex items-center justify-center mx-auto border-4 border-emergency-red/40 animate-pulse">
                  <AlertCircle className="w-10 h-10 text-emergency-red" />
                </div>
                <div className="space-y-4">
                  <h3 className="text-2xl font-black uppercase leading-tight italic">Confirm <span className="text-emergency-red">SOS Trigger?</span></h3>
                  <p className="text-sm opacity-60 font-medium">
                    This will alert the emergency response network and share your live GPS coordinates.
                  </p>
                </div>
                <div className="space-y-3">
                  <button 
                    onClick={handleSOSSubmit}
                    disabled={isSubmitting}
                    className="w-full py-5 bg-emergency-red text-white rounded-3xl font-black uppercase tracking-[0.2em] shadow-xl shadow-emergency-red/20 hover:scale-105 active:scale-95 transition-all text-sm"
                  >
                    {isSubmitting ? "TRANSMITTING..." : "CONFIRM & SEND"}
                  </button>
                  <button 
                    onClick={() => setShowConfirm(false)}
                    className="w-full py-4 text-[10px] font-black uppercase tracking-widest opacity-40 hover:opacity-100 transition-opacity"
                  >
                    Cancel Action
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

// Add missing icon
function ArrowLeft({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>
    </svg>
  );
}

function Clock({ className }: { className?: string }) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

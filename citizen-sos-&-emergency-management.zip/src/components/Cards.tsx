import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  delay?: number;
}

export function FeatureCard({ icon: Icon, title, description, delay = 0 }: FeatureCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="bg-navy-light/40 backdrop-blur-xl p-8 rounded-[2rem] border border-white/5 hover:border-emergency-red/50 transition-all group relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-24 h-24 bg-emergency-red/5 blur-[40px] group-hover:bg-emergency-red/10" />
      <div className="w-14 h-14 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-emergency-red/20 group-hover:scale-110 transition-all">
        <Icon className="w-7 h-7 text-emergency-red" />
      </div>
      <h3 className="text-xl font-black uppercase italic tracking-tighter mb-4 group-hover:text-emergency-red transition-colors">{title}</h3>
      <p className="text-white/40 text-xs font-bold leading-relaxed uppercase tracking-widest">{description}</p>
    </motion.div>
  );
}

interface EmergencyCategoryCardProps {
  icon: LucideIcon;
  label: string;
  active?: boolean;
  onClick?: () => void;
  className?: string;
  key?: string | number;
}

export function EmergencyCategoryCard({ icon: Icon, label, active, onClick, className }: EmergencyCategoryCardProps) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col items-center justify-center p-6 rounded-3xl border transition-all gap-4 group",
        active 
          ? "bg-emergency-red/20 border-emergency-red shadow-lg shadow-emergency-red/10" 
          : "bg-white/[0.03] border-white/5 hover:bg-white/[0.08] hover:border-white/20",
        className
      )}
    >
      <Icon className={cn("w-10 h-10 transition-all", active ? "text-emergency-red" : "text-white/20 group-hover:text-white group-hover:scale-110")} />
      <span className={cn("text-[10px] font-black uppercase tracking-[0.2em]", active ? "text-white" : "text-white/20 group-hover:text-white")}>{label}</span>
    </button>
  );
}

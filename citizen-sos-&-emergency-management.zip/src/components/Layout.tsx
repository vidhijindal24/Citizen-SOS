import { Shield, PhoneCall, AlertTriangle, Users, MapPin, Activity, Flame, Siren, UserX, Car, CloudLightning, Menu, X } from 'lucide-react';
import { ReactNode, useState, useEffect } from 'react';
import { NavLink, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '../lib/utils';
import ProfFooter from './Footer';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={cn(
      "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
      scrolled ? "bg-navy/80 backdrop-blur-xl border-b border-white/5 py-3" : "bg-transparent py-6"
    )}>
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <Shield className="w-8 h-8 text-emergency-red group-hover:rotate-12 transition-transform" />
          <span className="text-xl font-black italic tracking-tighter uppercase">Citizen_SOS</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <NavLink to="/" className={({ isActive }) => cn("text-xs font-black uppercase tracking-widest opacity-60 hover:opacity-100 transition-opacity", isActive && "opacity-100 text-emergency-red")}>Archive</NavLink>
          <NavLink to="/sos" className={({ isActive }) => cn("text-xs font-black uppercase tracking-widest opacity-60 hover:opacity-100 transition-opacity", isActive && "opacity-100 text-emergency-red")}>Signal_Bridge</NavLink>
          <NavLink to="/dashboard" className="px-5 py-2 bg-white/5 border border-white/10 rounded-full text-xs font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all">Command_Nexus</NavLink>
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-navy/95 backdrop-blur-2xl flex flex-col items-center justify-center gap-8 md:hidden"
          >
            <Link to="/" onClick={() => setIsMenuOpen(false)} className="text-2xl font-black uppercase tracking-widest">Home</Link>
            <Link to="/sos" onClick={() => setIsMenuOpen(false)} className="text-2xl font-black uppercase tracking-widest">SOS_Signal</Link>
            <Link to="/dashboard" onClick={() => setIsMenuOpen(false)} className="text-2xl font-black uppercase tracking-widest text-emerald-500">Command_Link</Link>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen w-full flex flex-col bg-navy text-slate-100">
      <Header />
      <main className="flex-1">
        {children}
      </main>
      <ProfFooter />
    </div>
  );
}

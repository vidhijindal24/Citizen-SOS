import { Phone, Shield, ExternalLink } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative z-20 bg-black/80 backdrop-blur-3xl border-t border-white/5 py-12 px-6 overflow-hidden">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-2 space-y-6">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6 text-emergency-red" />
            <span className="text-xl font-black uppercase tracking-tighter italic">Citizen_SOS</span>
          </div>
          <p className="text-sm opacity-40 leading-relaxed max-w-sm">
            Citizen SOS is a state-of-the-art emergency management protocol designed to bridge the gap between distressed citizens and first responders. Built on the Atlas Real-time Network.
          </p>
          <div className="flex items-center gap-6 pt-2">
            <div className="text-center">
              <p className="text-[10px] uppercase font-black tracking-widest opacity-20 mb-2">Public Safety Protocol</p>
              <div className="px-3 py-1 bg-white/5 border border-white/10 rounded text-[10px] font-bold">V-CERT v9.2.1</div>
            </div>
            <div className="text-center">
              <p className="text-[10px] uppercase font-black tracking-widest opacity-20 mb-2">System Status</p>
              <div className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-500 rounded text-[10px] font-bold flex items-center gap-2">
                <div className="w-1 h-1 rounded-full bg-emerald-500 animate-pulse" />
                Operational
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="text-[10px] font-black uppercase tracking-[0.2em] opacity-30">Emergency Helplines</h4>
          <div className="space-y-4">
            <div className="flex items-center gap-4 group cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center group-hover:bg-red-500 transition-all">
                <Phone className="w-4 h-4 text-red-500 group-hover:text-white" />
              </div>
              <div>
                <p className="text-xs font-black uppercase">National Guard</p>
                <p className="text-sm font-mono text-red-500">100 / 112</p>
              </div>
            </div>
            <div className="flex items-center gap-4 group cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center group-hover:bg-blue-500 transition-all">
                <Phone className="w-4 h-4 text-blue-500 group-hover:text-white" />
              </div>
              <div>
                <p className="text-xs font-black uppercase">Medical/Ambulance</p>
                <p className="text-sm font-mono text-blue-500">102</p>
              </div>
            </div>
            <div className="flex items-center gap-4 group cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center group-hover:bg-yellow-500 transition-all">
                <Phone className="w-4 h-4 text-yellow-500 group-hover:text-white" />
              </div>
              <div>
                <p className="text-xs font-black uppercase">Fire Control</p>
                <p className="text-sm font-mono text-yellow-500">101</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="text-[10px] font-black uppercase tracking-[0.2em] opacity-30">Legal & Privacy</h4>
          <div className="space-y-3">
            {[
              "Transparency Report",
              "Data Encryption Policy",
              "Contact Command",
              "Dispatcher Login"
            ].map(link => (
              <a key={link} href="#" className="block text-[11px] font-bold opacity-30 hover:opacity-100 hover:translate-x-1 transition-all flex items-center gap-2 group">
                {link}
                <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-40" />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
        <p className="text-[10px] font-black uppercase tracking-widest opacity-20">
          © 2026 ATLAS DEFENSE SYSTEMS. ALL SIGNAL CHANNELS ENCRYPTED.
        </p>
        <div className="flex items-center gap-6">
          <span className="text-[9px] font-black uppercase tracking-tighter opacity-10 italic">Secured by Quantum-Shield</span>
          <div className="h-1 w-24 bg-white/5 relative overflow-hidden rounded-full">
            <div className="absolute inset-0 bg-red-500/20 translate-x-[-50%] animate-pulse" />
          </div>
        </div>
      </div>
    </footer>
  );
}

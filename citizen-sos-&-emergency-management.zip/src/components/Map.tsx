import { MapContainer, TileLayer, Marker, Popup, useMap, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useEffect, useState } from 'react';

// Fix for default marker icons using CDN URLs to avoid build issues
const icon = "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png";
const iconShadow = "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png";

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

interface MapProps {
  center?: [number, number];
  zoom?: number;
  markers?: Array<{
    id: string;
    position: [number, number];
    label?: string;
    type?: string;
    priority?: string;
  }>;
  onLocationSelect?: (lat: number, lng: number) => void;
  onMarkerClick?: (id: string) => void;
  showUserLocation?: boolean;
}

function LocationMarker({ onLocationSelect }: { onLocationSelect?: (lat: number, lng: number) => void }) {
  const [position, setPosition] = useState<L.LatLng | null>(null);
  const map = useMap();

  useEffect(() => {
    map.locate().on("locationfound", function (e) {
      setPosition(e.latlng);
      map.flyTo(e.latlng, map.getZoom());
      if (onLocationSelect) {
        onLocationSelect(e.latlng.lat, e.latlng.lng);
      }
    });
  }, [map, onLocationSelect]);

  useMapEvents({
    click(e) {
      if (onLocationSelect) {
        setPosition(e.latlng);
        onLocationSelect(e.latlng.lat, e.latlng.lng);
      }
    },
  });

  return position === null ? null : (
    <Marker position={position}>
      <Popup>You are here (or selected location)</Popup>
    </Marker>
  );
}

function ChangeView({ center, zoom }: { center: [number, number]; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
}

export default function Map({ 
  center = [20.5937, 78.9629], 
  zoom = 5, 
  markers = [], 
  onLocationSelect, 
  onMarkerClick,
  showUserLocation = false 
}: MapProps) {
  return (
    <MapContainer center={center} zoom={zoom} className="h-full w-full">
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      {showUserLocation && <LocationMarker onLocationSelect={onLocationSelect} />}
      
      {markers.map((marker) => (
        <Marker 
          key={marker.id} 
          position={marker.position}
          eventHandlers={{
            click: () => onMarkerClick && onMarkerClick(marker.id),
          }}
          icon={L.divIcon({
            className: 'custom-div-icon',
            html: `<div class="w-4 h-4 rounded-full border-2 border-white shadow-lg ${
              marker.priority === 'HIGH' ? 'bg-red-600' : 
              marker.priority === 'MEDIUM' ? 'bg-orange-500' : 'bg-yellow-500'
            }"></div>`,
            iconSize: [16, 16],
            iconAnchor: [8, 8]
          })}
        >
          <Popup>
            <div className="text-navy">
              <p className="font-bold">{marker.type}</p>
              <p className="text-xs">{marker.label}</p>
              <p className="text-[10px] opacity-60">Status: {marker.id}</p>
            </div>
          </Popup>
        </Marker>
      ))}

      {!showUserLocation && <ChangeView center={center} zoom={zoom} />}
    </MapContainer>
  );
}

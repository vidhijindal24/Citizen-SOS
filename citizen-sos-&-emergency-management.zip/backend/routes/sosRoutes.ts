import express from "express";
import { sosController } from "../controllers/sosController";

const router = express.Router();

router.post("/create", sosController.createAlert);
router.get("/all", sosController.getAllAlerts);
router.get("/:id", sosController.getAlertById);
router.put("/update/:id", sosController.updateAlertStatus);
router.put("/assign/:id", sosController.assignResponder);
router.delete("/delete/:id", sosController.deleteAlert);

export default router;

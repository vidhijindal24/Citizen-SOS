import { Request, Response } from "express";
import { Alert } from "../models/Alert";
import { sosCreateSchema, sosUpdateSchema } from "../middleware/validation";
import { Server } from "socket.io";
import mongoose from "mongoose";

const calculatePriority = (type: string) => {
  if (['Fire', 'Crime', 'Women Safety'].includes(type)) return 'CRITICAL';
  if (['Medical', 'Accident'].includes(type)) return 'MEDIUM';
  return 'LOW';
};

export const sosController = {
  createAlert: async (req: Request, res: Response) => {
    const io = req.app.get("io");
    console.log("--- SOS CREATE REQUEST START ---");
    console.log("⏰ Time:", new Date().toISOString());
    console.log("📩 Raw Payload:", JSON.stringify(req.body, null, 2));
    
    try {
      // 1. Zod Validation
      console.log("🔍 Step 1: Validating with Zod Schema...");
      const validatedData = sosCreateSchema.safeParse(req.body);
      
      if (!validatedData.success) {
        console.error("❌ Step 1: Zod Validation FAILED:", validatedData.error.format());
        return res.status(400).json({ 
          success: false,
          message: "Validation failed", 
          details: validatedData.error.issues 
        });
      }
      console.log("✅ Step 1: Zod Validation PASSED");

      // 2. Data Preparation
      console.log("🛠️ Step 2: Preparing alert object...");
      const alertData = {
        ...validatedData.data,
        priorityLevel: calculatePriority(validatedData.data.emergencyType)
      };
      console.log("📦 Final object for Mongoose:", JSON.stringify(alertData, null, 2));

      // 3. Database Operation
      console.log("💾 Step 3: Attempting MongoDB save()...");
      const newAlert = new Alert(alertData);
      
      // Explicitly check connection state before saving
      const dbState = mongoose.connection.readyState;
      console.log("📡 Mongoose Connection State:", dbState, "(1 is connected)");
      
      if (dbState !== 1) {
        console.warn("⚠️ Mongoose is NOT in connected state (1). Trying to save anyway (buffering)...");
      }

      const savedAlert = await newAlert.save();
      console.log("✨ Step 3: SUCCESS! Saved Alert ID:", savedAlert._id);

      // 4. Socket Emission
      console.log("📢 Step 4: Emitting socket event...");
      io.emit("alert-received", savedAlert);
      console.log("✅ Step 4: Socket emitted successfully");
      
      console.log("--- SOS CREATE REQUEST SUCCESS ---");
      return res.status(201).json({ 
        success: true,
        message: "SOS alert created successfully", 
        data: savedAlert
      });
    } catch (error: any) {
      console.error("⛔ SOS CREATE FATAL ERROR:");
      console.error("Name:", error.name);
      console.error("Message:", error.message);
      console.error("Stack:", error.stack);
      
      if (error.name === "ValidationError") {
        console.error("👉 Mongoose Validation Error Details:", error.errors);
        return res.status(400).json({ 
          success: false,
          message: "Mongoose validation failed", 
          details: error.errors 
        });
      }

      return res.status(500).json({ 
        success: false,
        message: "Internal server error during database operation",
        error: error.message 
      });
    }
  },

  getAllAlerts: async (_req: Request, res: Response) => {
    try {
      const alerts = await Alert.find().sort({ createdAt: -1 });
      return res.json({
        success: true,
        data: alerts
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false,
        message: "Failed to fetch alerts" 
      });
    }
  },

  getAlertById: async (req: Request, res: Response) => {
    try {
      const alert = await Alert.findById(req.params.id);
      if (!alert) return res.status(404).json({ 
        success: false,
        message: "Alert not found" 
      });
      return res.json({
        success: true,
        data: alert
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false,
        message: "Invalid alert ID" 
      });
    }
  },

  updateAlertStatus: async (req: Request, res: Response) => {
    try {
      const io = req.app.get("io");
      const { id } = req.params;
      const { status } = sosUpdateSchema.parse(req.body);

      const updatedAlert = await Alert.findByIdAndUpdate(
        id, 
        { status }, 
        { new: true }
      );

      if (!updatedAlert) {
        return res.status(404).json({ 
          success: false,
          message: "Alert not found" 
        });
      }

      io.emit("alert-status-changed", updatedAlert);
      return res.json({ 
        success: true,
        message: "Alert status updated",
        data: updatedAlert 
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          success: false,
          message: error.issues?.[0]?.message || "Validation error" 
        });
      }
      return res.status(500).json({ 
        success: false,
        message: "Failed to update alert" 
      });
    }
  },

  deleteAlert: async (req: Request, res: Response) => {
    try {
      const io = req.app.get("io");
      const deletedAlert = await Alert.findByIdAndDelete(req.params.id);
      if (!deletedAlert) return res.status(404).json({ 
        success: false,
        message: "Alert not found" 
      });
      
      io.emit("alert-deleted", req.params.id);
      return res.json({ 
        success: true, 
        message: "Alert deleted" 
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false,
        message: "Failed to delete alert" 
      });
    }
  },

  assignResponder: async (req: Request, res: Response) => {
    try {
      const io = req.app.get("io");
      const { id } = req.params;
      const { responderName } = req.body;

      if (!responderName) {
        return res.status(400).json({ 
          success: false,
          message: "Responder name is required" 
        });
      }

      const updatedAlert = await Alert.findByIdAndUpdate(
        id,
        { 
          assignedResponder: responderName,
          status: 'IN_PROGRESS' 
        },
        { new: true }
      );

      if (!updatedAlert) {
        return res.status(404).json({ 
          success: false,
          message: "Alert not found" 
        });
      }

      io.emit("alert-status-changed", updatedAlert);
      return res.json({ 
        success: true, 
        message: "Responder assigned successfully",
        data: updatedAlert 
      });
    } catch (error) {
      return res.status(500).json({ 
        success: false,
        message: "Failed to assign responder" 
      });
    }
  }
};

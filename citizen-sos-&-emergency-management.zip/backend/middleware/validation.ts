import { z } from "zod";

export const sosCreateSchema = z.object({
  fullName: z.string().min(2, "Name must be at least 2 characters"),
  phoneNumber: z.string().regex(/^\+?[0-9]\d{1,14}$/, "Invalid phone number format"),
  emergencyType: z.enum(["Medical", "Fire", "Crime", "Women Safety", "Accident", "Other"]),
  emergencyDescription: z.string().min(5, "Please explain the situation"),
  additionalNotes: z.string().optional(),
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
});

export const sosUpdateSchema = z.object({
  status: z.enum(["ACTIVE", "IN_PROGRESS", "RESOLVED"]),
});

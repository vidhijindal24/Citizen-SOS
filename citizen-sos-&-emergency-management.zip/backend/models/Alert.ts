import mongoose from "mongoose";

const alertSchema = new mongoose.Schema({
  fullName: { 
    type: String, 
    required: [true, "Full name is required"],
    trim: true
  },
  phoneNumber: { 
    type: String, 
    required: [true, "Phone number is required"],
    match: [/^\+?[0-9]\d{1,14}$/, "Please fill a valid phone number"]
  },
  emergencyType: { 
    type: String, 
    required: [true, "Emergency type is required"],
    enum: ["Medical", "Fire", "Crime", "Women Safety", "Accident", "Other"]
  },
  emergencyDescription: { 
    type: String, 
    required: [true, "Description is required"],
    maxLength: [1000, "Description cannot exceed 1000 characters"]
  },
  additionalNotes: { 
    type: String, 
    default: "" 
  },
  latitude: { 
    type: Number, 
    required: [true, "Latitude is field required"] 
  },
  longitude: { 
    type: Number, 
    required: [true, "Longitude is field required"] 
  },
  status: { 
    type: String, 
    default: "ACTIVE",
    enum: ["ACTIVE", "IN_PROGRESS", "RESOLVED"]
  },
  priorityLevel: { 
    type: String, 
    required: true,
    enum: ["CRITICAL", "MEDIUM", "LOW"]
  },
  assignedResponder: {
    type: String,
    default: null
  }
}, { timestamps: true });

export const Alert = mongoose.model("Alert", alertSchema, "sos_alerts");

import mongoose from "mongoose";

export const connectDB = async () => {
  let MONGODB_URI = process.env.MONGODB_URI;
  
  if (!MONGODB_URI) {
    console.error("❌ ERROR: MONGODB_URI is MISSING in environment variables.");
    return;
  }

  // Remove accidental spaces
  MONGODB_URI = MONGODB_URI.trim();
  
  // Log a masked version for debugging without exposing secrets
  const maskedUri = MONGODB_URI.replace(/(\/\/.*:)(.*)(@)/, "$1****$3");
  console.log(`🔌 Attempting to connect to MongoDB: ${maskedUri}`);

  try {
    mongoose.set('strictQuery', false);
    
    // Set up listeners BEFORE connecting
    mongoose.connection.on('connected', () => {
      console.log('💚 Mongoose event: Connected to', mongoose.connection.name);
    });

    mongoose.connection.on('error', err => {
      console.error('❌ Mongoose event: Error', err);
    });

    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️ Mongoose event: Disconnected');
    });

    await mongoose.connect(MONGODB_URI, {
      serverSelectionTimeoutMS: 10000,
      heartbeatFrequencyMS: 2000,
      connectTimeoutMS: 10000,
    });
    
    console.log("✅ MongoDB Atlas Connected Successfully");
    console.log(`🔌 Database Name: ${mongoose.connection.name}`);
    console.log(`📡 Connection State: ${mongoose.connection.readyState} (1 = Connected)`);
    
    // Automatic Backend Verification: Insert a sample document if collection is empty
    try {
      const Alert = mongoose.model("Alert");
      const count = await Alert.countDocuments();
      console.log(`📊 Current SOS alerts in database: ${count}`);
      
      if (count === 0) {
        console.log("🌱 Database is empty. Inserting seed verification document...");
        const seedAlert = new Alert({
          fullName: "System Boot Verification",
          phoneNumber: "+1000000000",
          emergencyType: "Other",
          emergencyDescription: "This is an automated system verification document created on backend startup.",
          latitude: 0,
          longitude: 0,
          priorityLevel: "LOW",
          status: "RESOLVED"
        });
        await seedAlert.save();
        console.log("✨ Seed document inserted successfully. Backend DB is fully operational.");
      } else {
        const latest = await Alert.findOne().sort({ createdAt: -1 });
        console.log("🔍 Recent Activity Found. Latest ID:", latest?._id);
      }
    } catch (seedErr: any) {
      console.error("⚠️ Note: Seed check skipped or failed:", seedErr.message);
    }

  } catch (err: any) {
    console.error("❌ MongoDB Connection Initial Failure:");
    console.error(err.message);
    if (err.message.includes("authentication failed")) {
      console.error("👉 RECOMMENDATION: Check username/password in MONGODB_URI secret.");
    }
  }
};

import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { createServer } from "http";
import { Server } from "socket.io";
import cors from "cors";
import dotenv from "dotenv";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { connectDB } from "./backend/config/db";
import sosRoutes from "./backend/routes/sosRoutes";
import { Alert } from "./backend/models/Alert";
import mongoose from "mongoose";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  // Connect to Database
  await connectDB();

  const app = express();
  const PORT = 3000;
  const httpServer = createServer(app);
  
  // Real-time Gateway
  const io = new Server(httpServer, {
    cors: { 
      origin: process.env.NODE_ENV === "production" ? process.env.FRONTEND_URL : "*",
      methods: ["GET", "POST"]
    },
  });

  // Make IO accessible to routes
  app.set("io", io);

  // Security Middlewares
  app.use(helmet({
    contentSecurityPolicy: false, 
  }));
  app.use(cors());
  app.use(express.json());

  // Priority API Routes
  app.use("/api/sos", sosRoutes);
  
  app.get("/api/health", (req, res) => {
    res.json({ 
      success: true,
      status: "ok", 
      db: mongoose.connection.readyState === 1 ? "connected" : "disconnected"
    });
  });

  // Rate Limiting
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 1000,
    message: { 
      success: false, 
      message: "Too many requests from this IP, please try again later" 
    },
  });
  app.use("/api", limiter);

  // Debug Logger for API
  app.use("/api", (req, res, next) => {
    console.log(`📡 API [${req.method}] ${req.originalUrl}`);
    next();
  });

  // API Routes
  // (Moved up)

  app.get("/api/sos-test/test-insert", async (req, res) => {
    console.log("🛠️ Manual test-insert route triggered");
    try {
      const testAlert = new Alert({
        fullName: "Manual Dashboard Test",
        phoneNumber: "+1999999999",
        emergencyType: "Other",
        emergencyDescription: "Manual verification test from dashboard at " + new Date().toISOString(),
        latitude: 12.34,
        longitude: 56.78,
        priorityLevel: "LOW"
      });
      const saved = await testAlert.save();
      console.log("✅ Test alert saved:", saved._id);
      
      // Fetch it back to double check
      const fetched = await Alert.findById(saved._id);
      
      res.json({ 
        success: true, 
        message: "Manual test insertion and fetch-back successful", 
        data: fetched
      });
    } catch (err: any) {
      console.error("❌ Manual test-insert FAILED:", err.message);
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Catch-all for undefined /api routes
  app.all("/api/*", (req, res) => {
    console.log(`[DEBUG] 404 API Fallback hit for ${req.method} ${req.url}`);
    res.status(404).json({ 
      success: false, 
      message: `API endpoint not found on this server: ${req.method} ${req.originalUrl}` 
    });
  });

  // Global API Error Handler
  app.use("/api", (err: any, req: any, res: any, next: any) => {
    console.error("🔥 Global API Error:", err);
    res.status(err.status || 500).json({
      success: false,
      message: err.message || "Internal Server Error",
    });
  });

  // Vite Integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(Number(PORT), "0.0.0.0", () => {
    console.log(`🚀 Emergency System Active on Port ${PORT}`);
  });
}

startServer();
